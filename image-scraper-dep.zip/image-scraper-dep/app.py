from flask import Flask, render_template, request, jsonify
from flask_cors import CORS, cross_origin
from bs4 import BeautifulSoup
import requests

IMG_Path_STROAGE = '/tmp/'

app = Flask(__name__)


@app.route('/', methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")


@app.route('/review', methods=['POST', 'GET'])  # route to show the review comments in a web UI
@cross_origin()
def index():
    reviews = []
    if request.method == 'POST':
        try:
            URL = request.form['content'].replace(" ", "")
            PATH = request.form['content'].replace(" ", "")
            EXP = request.form['content'].replace(" ", "")
            if len(EXP) == 0:
                EXP = 'ul', {"class": "img_list"}
            if len(PATH) == 0:
                IMG_Path_STROAGE = PATH
            html = requests.get(URL).text
            soup = BeautifulSoup(html, 'lxml')
            img_ul = soup.find_all(EXP)
            import os

            os.makedirs('/tmp/images', exist_ok=True)
            for ul in img_ul:
                imgs = ul.find_all('img')
                for img in imgs:
                    url = img['src']
                    r = requests.get(url, stream=True)
                    image_name = url.split('/')[-1]
                    with open(IMG_Path_STROAGE + image_name, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=128):
                            f.write(chunk)
                    print('Saved %s' % image_name)
                    path = IMG_Path_STROAGE + image_name
                    mydict = {"Image Name": image_name, "Path": path}
                    reviews.append(mydict)

            return render_template('results.html', reviews=reviews[0:(len(reviews) - 1)])
        except Exception as e:
            print('The Exception message is please check URL you enter ', e)
            return 'something is wrong'
    # return render_template('results.html')

    else:
        return render_template('index.html')


if __name__ == "__main__":
    # app.run(host='127.0.0.1', port=8001, debug=True)
    app.run(debug=True)
